import { useCallback, useEffect, useState } from "react";
import { setToken, setUnauthorizedHandler } from "./api.js";
import Login from "./components/Login.jsx";
import Desk from "./components/Desk.jsx";
import Admin from "./components/Admin.jsx";

function loadSession() {
  try {
    const saved = JSON.parse(localStorage.getItem("session"));
    return localStorage.getItem("token") ? saved : null;
  } catch {
    return null;
  }
}

export default function App() {
  const [session, setSession] = useState(loadSession);
  const [view, setView] = useState(() => (loadSession()?.role === "ADMIN" ? "admin" : "desk"));

  const logout = useCallback(() => {
    setToken(null);
    localStorage.removeItem("session");
    setSession(null);
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(logout);
  }, [logout]);

  function handleLogin(auth) {
    setToken(auth.token);
    const next = { username: auth.username, fullName: auth.fullName, role: auth.role };
    localStorage.setItem("session", JSON.stringify(next));
    setSession(next);
    setView(auth.role === "ADMIN" ? "admin" : "desk");
  }

  if (!session) return <Login onLogin={handleLogin} />;

  const isAdmin = session.role === "ADMIN";

  return (
    <main className="page">
      <header className="topbar">
        <div>
          <h1>Parking System</h1>
          <p>
            Signed in as {session.fullName} ({isAdmin ? "Admin" : "Staff"})
          </p>
        </div>
        <nav className="topnav" aria-label="Main">
          {isAdmin && (
            <>
              <button
                className={view === "admin" ? "tab active" : "tab"}
                onClick={() => setView("admin")}
              >
                Admin dashboard
              </button>
              <button
                className={view === "desk" ? "tab active" : "tab"}
                onClick={() => setView("desk")}
              >
                Parking desk
              </button>
            </>
          )}
          <button className="tab plain" onClick={logout}>
            Sign out
          </button>
        </nav>
      </header>

      {isAdmin && view === "admin" ? <Admin currentUser={session.username} /> : <Desk />}
    </main>
  );
}
