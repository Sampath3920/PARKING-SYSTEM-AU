import { categoryLabel, dateTime, typeLabel } from "../utils.js";

export default function ParkedTable({ tickets }) {
  return (
    <section className="tickets">
      <h2>Parked now ({tickets.length})</h2>
      {tickets.length === 0 ? (
        <p className="empty">Nothing is parked. Issue a ticket when a vehicle arrives.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Category</th>
                <th>ID</th>
                <th>Vehicle</th>
                <th>Type</th>
                <th>Bay</th>
                <th>Arrived</th>
              </tr>
            </thead>
            <tbody>
              {tickets.map((t) => (
                <tr key={t.id}>
                  <td>{t.personName}</td>
                  <td>{categoryLabel[t.category]}</td>
                  <td>{t.personRef}</td>
                  <td>{t.vehicleRegNumber}</td>
                  <td>{typeLabel[t.type]}</td>
                  <td>{t.spotNumber}</td>
                  <td>{dateTime(t.inTime)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
