import { useState } from "react";
import { enterVehicle } from "../api.js";
import { rupees } from "../utils.js";

function rateHint(category, rates) {
  if (!rates) return "";
  if (category === "VISITOR") {
    return `Visitors: first ${rates.visitorFreeMinutes} minutes free, then ${rupees(rates.visitorHourlyRate)} per hour.`;
  }
  return `Students and faculty: ${rupees(rates.studentFacultyDayRate)} per day.`;
}

export default function EntryForm({ rates, onDone }) {
  const [category, setCategory] = useState("STUDENT");
  const [personName, setPersonName] = useState("");
  const [personRef, setPersonRef] = useState("");
  const [reg, setReg] = useState("");
  const [type, setType] = useState("CAR");
  const [message, setMessage] = useState(null);
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    try {
      const ticket = await enterVehicle({
        vehicleRegNumber: reg,
        type,
        category,
        personName,
        personRef,
      });
      setMessage({
        kind: "ok",
        text: `${ticket.vehicleRegNumber} parked in bay ${ticket.spotNumber}.`,
      });
      setReg("");
      setPersonName("");
      setPersonRef("");
      onDone();
    } catch (err) {
      setMessage({ kind: "error", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  const refLabel =
    category === "STUDENT"
      ? "Roll number (optional)"
      : category === "FACULTY"
        ? "Employee ID (optional)"
        : "Phone number (optional)";

  return (
    <form className="desk" onSubmit={submit}>
      <h2>Vehicle arriving</h2>
      <label>
        Who is parking
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="STUDENT">Student</option>
          <option value="FACULTY">Faculty</option>
          <option value="VISITOR">Visitor</option>
        </select>
      </label>
      <p className="hint">{rateHint(category, rates)}</p>
      <label>
        Name
        <input value={personName} onChange={(e) => setPersonName(e.target.value)} maxLength={100} required />
      </label>
      <label>
        {refLabel}
        <input value={personRef} onChange={(e) => setPersonRef(e.target.value)} maxLength={50} />
      </label>
      <label>
        Vehicle registration number
        <input
          value={reg}
          onChange={(e) => setReg(e.target.value)}
          maxLength={20}
          required
          autoComplete="off"
        />
      </label>
      <label>
        Vehicle type
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="CAR">Car</option>
          <option value="BIKE">Bike</option>
        </select>
      </label>
      <button disabled={busy}>Issue ticket</button>
      {message && <p className={`banner ${message.kind}`}>{message.text}</p>}
    </form>
  );
}
