import { useCallback, useEffect, useState } from "react";
import { getSpots, removeSpot } from "../api.js";
import AddSlots from "./AddSlots.jsx";
import Bays from "./Bays.jsx";

export default function SlotsPanel() {
  const [spots, setSpots] = useState([]);
  const [error, setError] = useState("");

  const refresh = useCallback(() => {
    getSpots()
      .then((rows) => {
        setSpots(rows);
        setError("");
      })
      .catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function remove(number) {
    if (!window.confirm(`Remove bay ${number}? Past tickets keep their record.`)) return;
    try {
      await removeSpot(number);
      refresh();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <>
      {error && <p className="banner error">{error}</p>}
      <Bays spots={spots} onRemove={remove} />
      <AddSlots onDone={refresh} />
    </>
  );
}
