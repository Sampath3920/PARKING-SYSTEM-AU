import { useEffect, useState } from "react";
import { getHistory } from "../api.js";
import { categoryLabel, dateTime, paymentLabel, paymentStatusLabel, rupees, typeLabel } from "../utils.js";

export default function History() {
  const [query, setQuery] = useState("");
  const [tickets, setTickets] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => {
      getHistory(query.trim())
        .then((rows) => {
          setTickets(rows);
          setError("");
        })
        .catch((err) => setError(err.message));
    }, 250);
    return () => clearTimeout(timer);
  }, [query]);

  return (
    <section className="panel">
      <h2>All tickets</h2>
      <label className="search">
        Search by name, ID or vehicle number
        <input value={query} onChange={(e) => setQuery(e.target.value)} />
      </label>
      {error && <p className="banner error">{error}</p>}
      {tickets.length === 0 ? (
        <p className="empty">{query ? "No tickets match that search." : "No tickets yet."}</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Category</th>
                <th>ID</th>
                <th>Vehicle</th>
                <th>Type</th>
                <th>Bay</th>
                <th>In</th>
                <th>Out</th>
                <th>Fare</th>
                <th>Status</th>
                <th>Payment</th>
              </tr>
            </thead>
            <tbody>
              {tickets.map((t) => (
                <tr key={t.id}>
                  <td>{t.personName}</td>
                  <td>{categoryLabel[t.category]}</td>
                  <td>{t.personRef}</td>
                  <td>{t.vehicleRegNumber}</td>
                  <td>{typeLabel[t.type]}</td>
                  <td>{t.spotNumber}</td>
                  <td>{dateTime(t.inTime)}</td>
                  <td>{dateTime(t.outTime)}</td>
                  <td title={t.fareNote || ""}>{t.price == null ? "" : rupees(t.price)}</td>
                  <td>{t.status === "PARKED" ? "Parked" : "Left"}</td>
                  <td>
                    {t.paymentStatus === "PAID"
                      ? `Paid (${paymentLabel[t.paymentMethod]})`
                      : paymentStatusLabel[t.paymentStatus] || ""}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
