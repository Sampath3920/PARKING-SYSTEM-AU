import { useState } from "react";
import { login, register } from "../api.js";

export default function Login({ onLogin }) {
  const [mode, setMode] = useState("signin");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const auth =
        mode === "signin"
          ? await login(username, password)
          : await register(username, password, fullName);
      onLogin(auth);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const creating = mode === "register";

  return (
    <main className="login-page">
      <form className="login-card" onSubmit={submit}>
        <h1>Parking System</h1>
        <p className="muted">{creating ? "Create a staff account" : "Sign in to continue"}</p>

        {creating && (
          <label>
            Full name
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          </label>
        )}
        <label>
          Username
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
            required
          />
        </label>
        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={creating ? "new-password" : "current-password"}
            minLength={creating ? 8 : undefined}
            required
          />
        </label>

        <button disabled={busy}>{creating ? "Create account" : "Sign in"}</button>
        {error && <p className="banner error">{error}</p>}

        <p className="switch">
          {creating ? "Already have an account? " : "Need an account? "}
          <button
            type="button"
            className="link"
            onClick={() => {
              setMode(creating ? "signin" : "register");
              setError("");
            }}
          >
            {creating ? "Sign in" : "Create one"}
          </button>
        </p>
      </form>
    </main>
  );
}
