import { useState } from "react";
import { exitVehicle } from "../api.js";
import { categoryLabel, rupees } from "../utils.js";

export default function ExitForm({ onDone }) {
  const [reg, setReg] = useState("");
  const [receipt, setReceipt] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    try {
      const ticket = await exitVehicle(reg);
      setReceipt(ticket);
      setError("");
      setReg("");
      onDone();
    } catch (err) {
      setReceipt(null);
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="desk" onSubmit={submit}>
      <h2>Vehicle leaving</h2>
      <label>
        Vehicle registration number
        <input
          value={reg}
          onChange={(e) => setReg(e.target.value)}
          maxLength={20}
          required
          autoComplete="off"
        />
      </label>
      <button disabled={busy}>Calculate fare and release bay</button>
      {error && <p className="banner error">{error}</p>}
      {receipt && (
        <div className="receipt">
          <p>
            {receipt.personName} ({categoryLabel[receipt.category]}), {receipt.vehicleRegNumber}, left
            bay {receipt.spotNumber}
          </p>
          <p className="fare">{receipt.price === 0 ? "No charge" : rupees(receipt.price)}</p>
          <p>{receipt.fareNote}</p>
        </div>
      )}
    </form>
  );
}
