import { useState } from "react";
import { addSpots } from "../api.js";

export default function AddSlots({ onDone }) {
  const [type, setType] = useState("CAR");
  const [count, setCount] = useState(1);
  const [message, setMessage] = useState(null);
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    try {
      const created = await addSpots(type, Number(count));
      const first = created[0].number;
      const last = created[created.length - 1].number;
      setMessage({
        kind: "ok",
        text: created.length === 1 ? `Added bay ${first}.` : `Added bays ${first} to ${last}.`,
      });
      onDone();
    } catch (err) {
      setMessage({ kind: "error", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="desk inline" onSubmit={submit}>
      <h2>Add parking bays</h2>
      <div className="row">
        <label>
          Bay type
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="CAR">Car</option>
            <option value="BIKE">Bike</option>
          </select>
        </label>
        <label>
          How many
          <input
            type="number"
            min="1"
            max="50"
            value={count}
            onChange={(e) => setCount(e.target.value)}
            required
          />
        </label>
        <button disabled={busy}>Add bays</button>
      </div>
      {message && <p className={`banner ${message.kind}`}>{message.text}</p>}
    </form>
  );
}
