import { useState } from "react";
import { payTicket } from "../api.js";
import { categoryLabel, paymentLabel, rupees } from "../utils.js";

/** Fares for vehicles that have left but not paid yet. Pick a payment method, then press Paid. */
export default function PaymentPanel({ tickets, onDone }) {
  const [methods, setMethods] = useState({});
  const [busy, setBusy] = useState(null);
  const [message, setMessage] = useState(null);

  async function paid(ticket) {
    const method = methods[ticket.id] || "CASH";
    setBusy(ticket.id);
    try {
      await payTicket(ticket.vehicleRegNumber, method);
      setMessage({
        kind: "ok",
        text: `${ticket.vehicleRegNumber} marked as paid by ${paymentLabel[method]}. The admin has been notified.`,
      });
      onDone();
    } catch (err) {
      setMessage({ kind: "error", text: err.message });
    } finally {
      setBusy(null);
    }
  }

  return (
    <section className="tickets">
      <h2>Pending payments ({tickets.length})</h2>
      {message && <p className={`banner ${message.kind}`}>{message.text}</p>}
      {tickets.length === 0 ? (
        <p className="empty">No payments pending.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Vehicle</th>
                <th>Fare</th>
                <th>Payment method</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {tickets.map((t) => (
                <tr key={t.id}>
                  <td>{t.personName}</td>
                  <td>{categoryLabel[t.category]}</td>
                  <td>{t.vehicleRegNumber}</td>
                  <td>{rupees(t.price)}</td>
                  <td>
                    <select
                      value={methods[t.id] || "CASH"}
                      onChange={(e) => setMethods({ ...methods, [t.id]: e.target.value })}
                    >
                      {Object.entries(paymentLabel).map(([value, label]) => (
                        <option key={value} value={value}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <button disabled={busy === t.id} onClick={() => paid(t)}>
                      Paid
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
