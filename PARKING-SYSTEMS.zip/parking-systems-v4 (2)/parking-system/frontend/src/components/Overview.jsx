import { useEffect, useState } from "react";
import { getStats } from "../api.js";
import { categoryLabel, rupees } from "../utils.js";

export default function Overview() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getStats().then(setStats).catch((err) => setError(err.message));
  }, []);

  if (error) return <p className="banner error">{error}</p>;
  if (!stats) return <p className="empty">Loading...</p>;

  const max = Math.max(1, ...stats.lastSevenDays.map((d) => d.amount));

  return (
    <>
      <section className="tiles">
        <div className="tile">
          <span className="tile-value">
            {stats.freeSpots} / {stats.totalSpots}
          </span>
          <span className="tile-label">Bays free</span>
          <span className="tile-sub">
            Cars {stats.carFree}/{stats.carTotal}, bikes {stats.bikeFree}/{stats.bikeTotal}
          </span>
        </div>
        <div className="tile">
          <span className="tile-value">{stats.parkedNow}</span>
          <span className="tile-label">Parked now</span>
          <span className="tile-sub">{stats.entriesToday} arrivals today</span>
        </div>
        <div className="tile">
          <span className="tile-value">{rupees(stats.revenueToday)}</span>
          <span className="tile-label">Collected today</span>
        </div>
        <div className="tile">
          <span className="tile-value">{rupees(stats.revenueThisMonth)}</span>
          <span className="tile-label">Collected this month</span>
          <span className="tile-sub">All time {rupees(stats.revenueTotal)}</span>
        </div>
      </section>

      <section className="panel">
        <h2>Collected, last 7 days</h2>
        <div className="bars">
          {stats.lastSevenDays.map((d) => (
            <div key={d.date} className="bar-col">
              <span className="bar-amount">{rupees(d.amount)}</span>
              <div className="bar" style={{ height: `${Math.max(4, (d.amount / max) * 100)}px` }} />
              <span className="bar-day">
                {new Date(`${d.date}T00:00:00`).toLocaleDateString(undefined, { weekday: "short" })}
              </span>
            </div>
          ))}
        </div>
      </section>

      <section className="panel">
        <h2>Collected by category</h2>
        <table>
          <tbody>
            {Object.keys(categoryLabel).map((key) => (
              <tr key={key}>
                <td>{categoryLabel[key]}</td>
                <td>{rupees(stats.revenueByCategory[key])}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </>
  );
}
