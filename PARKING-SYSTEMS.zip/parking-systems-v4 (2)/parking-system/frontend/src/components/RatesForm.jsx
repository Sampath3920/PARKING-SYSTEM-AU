import { useEffect, useState } from "react";
import { getRates, updateRates } from "../api.js";

export default function RatesForm() {
  const [dayRate, setDayRate] = useState("");
  const [freeMinutes, setFreeMinutes] = useState("");
  const [hourRate, setHourRate] = useState("");
  const [message, setMessage] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getRates()
      .then((r) => {
        setDayRate(String(r.studentFacultyDayRate));
        setFreeMinutes(String(r.visitorFreeMinutes));
        setHourRate(String(r.visitorHourlyRate));
      })
      .catch((err) => setMessage({ kind: "error", text: err.message }));
  }, []);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    try {
      await updateRates({
        studentFacultyDayRate: Number(dayRate),
        visitorFreeMinutes: Number(freeMinutes),
        visitorHourlyRate: Number(hourRate),
      });
      setMessage({ kind: "ok", text: "Fares saved. They apply to vehicles that leave from now on." });
    } catch (err) {
      setMessage({ kind: "error", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="panel narrow" onSubmit={submit}>
      <h2>Fares</h2>
      <label>
        Student and faculty, per day (&#8377;)
        <input type="number" min="0" step="0.5" value={dayRate} onChange={(e) => setDayRate(e.target.value)} required />
      </label>
      <label>
        Visitors, free minutes
        <input type="number" min="0" max="1440" value={freeMinutes} onChange={(e) => setFreeMinutes(e.target.value)} required />
      </label>
      <label>
        Visitors, per hour after the free minutes (&#8377;)
        <input type="number" min="0" step="0.5" value={hourRate} onChange={(e) => setHourRate(e.target.value)} required />
      </label>
      <p className="hint">
        Students and faculty pay for each calendar day the vehicle is parked. Visitors pay for each
        started hour once the free minutes are used up.
      </p>
      <button disabled={busy}>Save fares</button>
      {message && <p className={`banner ${message.kind}`}>{message.text}</p>}
    </form>
  );
}
