import { useCallback, useEffect, useState } from "react";
import { createUser, deleteUser, getUsers } from "../api.js";

export default function UsersPanel({ currentUser }) {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ fullName: "", username: "", password: "", role: "USER" });
  const [message, setMessage] = useState(null);

  const refresh = useCallback(() => {
    getUsers()
      .then(setUsers)
      .catch((err) => setMessage({ kind: "error", text: err.message }));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  async function submit(event) {
    event.preventDefault();
    try {
      await createUser(form);
      setMessage({ kind: "ok", text: `Created ${form.username}.` });
      setForm({ fullName: "", username: "", password: "", role: "USER" });
      refresh();
    } catch (err) {
      setMessage({ kind: "error", text: err.message });
    }
  }

  async function remove(user) {
    if (!window.confirm(`Delete the account ${user.username}?`)) return;
    try {
      await deleteUser(user.id);
      refresh();
    } catch (err) {
      setMessage({ kind: "error", text: err.message });
    }
  }

  return (
    <>
      <form className="panel" onSubmit={submit}>
        <h2>Create an account</h2>
        <div className="row">
          <label>
            Full name
            <input value={form.fullName} onChange={set("fullName")} required />
          </label>
          <label>
            Username
            <input value={form.username} onChange={set("username")} minLength={3} required />
          </label>
          <label>
            Password
            <input type="password" value={form.password} onChange={set("password")} minLength={8} required />
          </label>
          <label>
            Role
            <select value={form.role} onChange={set("role")}>
              <option value="USER">Staff</option>
              <option value="ADMIN">Admin</option>
            </select>
          </label>
          <button>Create</button>
        </div>
        {message && <p className={`banner ${message.kind}`}>{message.text}</p>}
      </form>

      <section className="panel">
        <h2>Accounts</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Username</th>
                <th>Role</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.fullName}</td>
                  <td>{u.username}</td>
                  <td>{u.role === "ADMIN" ? "Admin" : "Staff"}</td>
                  <td>
                    {u.username !== currentUser && (
                      <button className="danger" onClick={() => remove(u)}>
                        Delete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
