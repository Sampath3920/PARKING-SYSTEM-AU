import { useCallback, useEffect, useState } from "react";
import { getPayments } from "../api.js";
import { categoryLabel, dateTime, paymentLabel, rupees } from "../utils.js";

/** Admin view: every vehicle whose user has pressed Paid. Refreshes every 10 seconds. */
export default function PaymentsPanel() {
  const [payments, setPayments] = useState([]);
  const [error, setError] = useState("");

  const load = useCallback(() => {
    getPayments()
      .then((rows) => {
        setPayments(rows);
        setError("");
      })
      .catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    load();
    const timer = setInterval(load, 10000);
    return () => clearInterval(timer);
  }, [load]);

  return (
    <section className="panel">
      <h2>Payments received ({payments.length})</h2>
      {error && <p className="banner error">{error}</p>}
      {payments.length === 0 ? (
        <p className="empty">No payments yet.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Paid at</th>
                <th>Name</th>
                <th>Category</th>
                <th>Vehicle</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Marked paid by</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((t) => (
                <tr key={t.id}>
                  <td>{dateTime(t.paidAt)}</td>
                  <td>{t.personName}</td>
                  <td>{categoryLabel[t.category]}</td>
                  <td>{t.vehicleRegNumber}</td>
                  <td>{rupees(t.price)}</td>
                  <td>{paymentLabel[t.paymentMethod]}</td>
                  <td>{t.paidBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
