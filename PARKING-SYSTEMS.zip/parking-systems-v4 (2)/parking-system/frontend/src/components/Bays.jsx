import { typeLabel } from "../utils.js";

export default function Bays({ spots, onRemove }) {
  if (spots.length === 0) {
    return <p className="empty">No bays yet. An admin needs to add some.</p>;
  }
  return (
    <section className="lot" aria-label="Parking bays">
      {spots.map((spot) => (
        <div key={spot.number} className={`bay ${spot.available ? "free" : "taken"}`}>
          <span className="bay-number">{spot.number}</span>
          <span className="bay-type">{typeLabel[spot.type]}</span>
          <span className="bay-state">{spot.available ? "Free" : "Taken"}</span>
          {onRemove && spot.available && (
            <button className="bay-remove" onClick={() => onRemove(spot.number)}>
              Remove bay
            </button>
          )}
        </div>
      ))}
    </section>
  );
}
