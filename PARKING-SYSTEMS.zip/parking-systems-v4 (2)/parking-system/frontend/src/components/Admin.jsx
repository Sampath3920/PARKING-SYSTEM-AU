import { useState } from "react";
import Overview from "./Overview.jsx";
import History from "./History.jsx";
import PaymentsPanel from "./PaymentsPanel.jsx";
import SlotsPanel from "./SlotsPanel.jsx";
import RatesForm from "./RatesForm.jsx";
import UsersPanel from "./UsersPanel.jsx";

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "history", label: "Tickets" },
  { id: "payments", label: "Payments" },
  { id: "bays", label: "Bays" },
  { id: "rates", label: "Fares" },
  { id: "users", label: "Accounts" },
];

export default function Admin({ currentUser }) {
  const [tab, setTab] = useState("overview");

  return (
    <>
      <div className="subtabs" role="tablist">
        {TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            className={tab === t.id ? "tab active" : "tab"}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "overview" && <Overview />}
      {tab === "history" && <History />}
      {tab === "payments" && <PaymentsPanel />}
      {tab === "bays" && <SlotsPanel />}
      {tab === "rates" && <RatesForm />}
      {tab === "users" && <UsersPanel currentUser={currentUser} />}
    </>
  );
}
