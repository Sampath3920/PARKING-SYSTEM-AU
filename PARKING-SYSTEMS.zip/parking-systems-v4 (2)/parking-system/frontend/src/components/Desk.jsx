import { useCallback, useEffect, useState } from "react";
import { getParked, getRates, getSpots, getUnpaid } from "../api.js";
import Bays from "./Bays.jsx";
import EntryForm from "./EntryForm.jsx";
import ExitForm from "./ExitForm.jsx";
import ParkedTable from "./ParkedTable.jsx";
import PaymentPanel from "./PaymentPanel.jsx";

/** The staff view: park and release vehicles, see who is parked, see free bays and pay fares. */
export default function Desk() {
  const [spots, setSpots] = useState([]);
  const [parked, setParked] = useState([]);
  const [rates, setRates] = useState(null);
  const [unpaid, setUnpaid] = useState([]);
  const [loadError, setLoadError] = useState("");

  const refresh = useCallback(async () => {
    try {
      const [s, p, r, u] = await Promise.all([getSpots(), getParked(), getRates(), getUnpaid()]);
      setSpots(s);
      setParked(p);
      setRates(r);
      setUnpaid(u);
      setLoadError("");
    } catch (err) {
      setLoadError(`Can't load data. Is the backend running on port 8081? (${err.message})`);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const free = (type) => spots.filter((s) => s.type === type && s.available).length;
  const total = (type) => spots.filter((s) => s.type === type).length;

  return (
    <>
      <p className="summary">
        <strong>{free("CAR")}</strong> of {total("CAR")} car bays free,{" "}
        <strong>{free("BIKE")}</strong> of {total("BIKE")} bike bays free
      </p>
      {loadError && <p className="banner error">{loadError}</p>}

      <Bays spots={spots} />

      <section className="desks">
        <EntryForm rates={rates} onDone={refresh} />
        <ExitForm onDone={refresh} />
      </section>

      <PaymentPanel tickets={unpaid} onDone={refresh} />

      <ParkedTable tickets={parked} />
    </>
  );
}
