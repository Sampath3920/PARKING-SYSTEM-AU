// Calls go through the Vite dev proxy (/api -> http://localhost:8081).
// For a deployed build, set VITE_API_URL (for example https://parking.example.com).
const BASE = import.meta.env.VITE_API_URL || "";

let token = localStorage.getItem("token");
let onUnauthorized = () => {};

export function setToken(value) {
  token = value;
  if (value) localStorage.setItem("token", value);
  else localStorage.removeItem("token");
}

export function setUnauthorizedHandler(handler) {
  onUnauthorized = handler;
}

async function request(path, options = {}) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${BASE}/api${path}`, { ...options, headers });
  const body = await response.json().catch(() => null);

  if (response.status === 401 && token) onUnauthorized();
  if (!response.ok) {
    if (body?.message) throw new Error(body.message);
    if (response.status === 401) throw new Error("Your session has ended. Sign in again.");
    if (response.status === 403) throw new Error("You don't have permission to do that.");
    throw new Error(`Request failed (${response.status})`);
  }
  return body;
}

const post = (path, data) => request(path, { method: "POST", body: JSON.stringify(data) });

// auth
export const login = (username, password) => post("/auth/login", { username, password });
export const register = (username, password, fullName) =>
  post("/auth/register", { username, password, fullName });

// everyone signed in
export const getSpots = () => request("/parking/spots");
export const getRates = () => request("/rates");
export const getParked = () => request("/tickets/parked");
export const enterVehicle = (data) => post("/tickets/entry", data);
export const getUnpaid = () => request("/tickets/unpaid");
export const payTicket = (vehicleRegNumber, method) => post("/tickets/pay", { vehicleRegNumber, method });
export const exitVehicle = (vehicleRegNumber) => post("/tickets/exit", { vehicleRegNumber });

// admin only
export const addSpots = (type, count) => post("/admin/spots", { type, count });
export const getPayments = () => request("/admin/payments");
export const getStats = () => request("/admin/stats");
export const getHistory = (q) => request(`/admin/tickets${q ? `?q=${encodeURIComponent(q)}` : ""}`);
export const updateRates = (rates) => request("/admin/rates", { method: "PUT", body: JSON.stringify(rates) });
export const removeSpot = (number) => request(`/admin/spots/${number}`, { method: "DELETE" });
export const getUsers = () => request("/admin/users");
export const createUser = (data) => post("/admin/users", data);
export const deleteUser = (id) => request(`/admin/users/${id}`, { method: "DELETE" });
