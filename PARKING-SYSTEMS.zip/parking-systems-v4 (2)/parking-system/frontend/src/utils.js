export const rupees = (value) => {
  const n = Number(value || 0);
  return `\u20B9${Number.isInteger(n) ? n : n.toFixed(2)}`;
};

export const dateTime = (value) => (value ? new Date(value).toLocaleString() : "");

export const categoryLabel = { STUDENT: "Student", FACULTY: "Faculty", VISITOR: "Visitor" };
export const typeLabel = { CAR: "Car", BIKE: "Bike" };

export const paymentLabel = {
  CASH: "Cash",
  UPI: "UPI",
  CREDIT_CARD: "Credit card",
  DEBIT_CARD: "Debit card",
  NET_BANKING: "Net banking",
  WALLET: "Wallet",
};
export const paymentStatusLabel = { PENDING: "Unpaid", PAID: "Paid", NOT_REQUIRED: "No charge" };
