# College Parking System (Spring Boot + React)

Staff park and release vehicles, admins see the numbers. Spring Boot REST API with login (JWT),
and a React (JavaScript) frontend with a staff view and an admin dashboard.

## Who can do what

| | Staff (USER) | Admin |
|---|---|---|
| Issue tickets, release vehicles, see who is parked | yes | yes |
| See which bays are free | yes | yes |
| Pay a fare (cash, UPI, cards, net banking, wallet) and press Paid | yes | yes |
| Add and remove bays | | yes |
| See payments received (who paid, which vehicle, method) | | yes |
| Dashboard: bays free, collected today / this month, last 7 days, by category | | yes |
| Search all ticket history | | yes |
| Change fares | | yes |
| Create and delete accounts | | yes |

## Fares (admin can change all three)
- **Student and faculty:** Rs. 1 per day. Each calendar day the vehicle is parked counts as one day,
  so arriving at 10 pm and leaving at 8 am the next morning is 2 days.
- **Visitor:** first 30 minutes free. After that, Rs. 5 per hour, rounded up to the next full hour
  (31 minutes = Rs. 5, 61 minutes = Rs. 10).

## Run it

Needs Java 17+, Maven 3.8+ and Node 18+.

**1. Backend** (http://localhost:8081)
```
cd backend
mvn spring-boot:run
```
It uses an in-memory H2 database by default (data resets on restart). To use MySQL, create a database
named `parking`, edit `src/main/resources/application-mysql.properties`, then run
`mvn spring-boot:run "-Dspring-boot.run.profiles=mysql"`.

**2. Frontend** (http://localhost:5173)
```
cd frontend
npm install
npm run dev
```

**3. Sign in** with the accounts created on first start:

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Staff | `user` | `user123` |

These demo passwords are for local testing only. Before real use set environment variables
`ADMIN_PASSWORD`, `STAFF_PASSWORD` and `JWT_SECRET` (32+ characters), for example in PowerShell:
```
$env:ADMIN_PASSWORD="a-long-password"; $env:STAFF_PASSWORD="another-long-one"; $env:JWT_SECRET="a-random-string-of-32-or-more-characters"
```
The MySQL profile refuses to start until they are set. The login page also lets anyone create a Staff
account, and a Staff account can mark fares as paid; set `ALLOW_REGISTRATION=false` to turn that off
and create accounts from the admin Accounts tab instead.

## Security notes
- Passwords are stored with bcrypt, at least 8 characters.
- 5 wrong sign-ins for the same account from the same address lock it for 15 minutes.
- The H2 web console is off. Admin-only endpoints are enforced on the server, not just hidden in the page.
- The Payments tab shows which account pressed Paid for each vehicle.
- Spring Boot is 3.5.16. Spring Boot 3.x no longer gets free security fixes, so plan a move to Spring Boot 4.

Run the fare tests with `mvn test` in `backend`.

## API

All endpoints except `/api/auth/*` need the header `Authorization: Bearer <token>`.

| Method | Path | Who | Purpose |
|---|---|---|---|
| POST | `/api/auth/login` | public | `{username, password}` returns a token |
| POST | `/api/auth/register` | public | Create a Staff account |
| GET | `/api/parking/spots` | signed in | All bays and whether they are free |
| GET | `/api/rates` | signed in | Current fares |
| GET | `/api/tickets/parked` | signed in | Who is parked now |
| POST | `/api/tickets/entry` | signed in | `{vehicleRegNumber, type, category, personName, personRef}` |
| POST | `/api/tickets/exit` | signed in | `{vehicleRegNumber}` returns the priced ticket |
| GET | `/api/tickets/unpaid` | signed in | Left vehicles whose fare is not paid yet |
| POST | `/api/tickets/pay` | signed in | `{vehicleRegNumber, method}` method: CASH, UPI, CREDIT_CARD, DEBIT_CARD, NET_BANKING, WALLET |
| GET | `/api/admin/stats` | admin | Dashboard numbers |
| GET | `/api/admin/tickets?q=` | admin | All tickets, optional search |
| PUT | `/api/admin/rates` | admin | Change fares |
| POST | `/api/admin/spots` | admin | `{type: CAR or BIKE, count}` adds bays |
| DELETE | `/api/admin/spots/{number}` | admin | Remove a free bay |
| GET | `/api/admin/payments` | admin | Vehicles that have been paid for |
| GET/POST/DELETE | `/api/admin/users` | admin | Manage accounts |

Errors return `{"message": "..."}` with 400, 401, 403, 404 or 409.
