package com.parkingsystem.model;

public enum PaymentStatus {
    PENDING,
    PAID,
    NOT_REQUIRED
}
