package com.parkingsystem.service;

import com.parkingsystem.dto.CreateUserRequest;
import com.parkingsystem.exception.ConflictException;
import com.parkingsystem.exception.NotFoundException;
import com.parkingsystem.model.AppUser;
import com.parkingsystem.repository.AppUserRepository;
import java.util.List;
import java.util.Locale;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

    private final AppUserRepository users;
    private final PasswordEncoder encoder;

    public UserService(AppUserRepository users, PasswordEncoder encoder) {
        this.users = users;
        this.encoder = encoder;
    }

    @Transactional(readOnly = true)
    public List<AppUser> list() {
        return users.findAllByOrderByUsernameAsc();
    }

    @Transactional
    public AppUser create(CreateUserRequest request) {
        String username = request.username().trim().toLowerCase(Locale.ROOT);
        if (users.existsByUsername(username)) {
            throw new ConflictException("That username is already taken.");
        }
        return users.save(new AppUser(username, encoder.encode(request.password()),
                request.fullName().trim(), request.role()));
    }

    @Transactional
    public void delete(Long id, String currentUsername) {
        AppUser user = users.findById(id).orElseThrow(() -> new NotFoundException("User not found."));
        if (user.getUsername().equals(currentUsername)) {
            throw new ConflictException("You can't delete the account you are signed in with.");
        }
        users.delete(user);
    }
}
