package com.parkingsystem.repository;

import com.parkingsystem.model.Category;
import com.parkingsystem.model.PaymentStatus;
import com.parkingsystem.model.Ticket;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    Optional<Ticket> findByVehicleRegNumberAndOutTimeIsNull(String vehicleRegNumber);

    List<Ticket> findByOutTimeIsNullOrderByInTimeDesc();

    List<Ticket> findAllByOrderByInTimeDesc();

    Optional<Ticket> findFirstByVehicleRegNumberAndPaymentStatusOrderByOutTimeDesc(String vehicleRegNumber, PaymentStatus status);

    List<Ticket> findByPaymentStatusOrderByOutTimeDesc(PaymentStatus status);

    List<Ticket> findByPaymentStatusOrderByPaidAtDesc(PaymentStatus status);

    long countByOutTimeIsNull();

    long countByInTimeGreaterThanEqual(LocalDateTime from);

    @Query("select coalesce(sum(t.price), 0.0) from Ticket t where t.outTime >= :from and t.outTime < :to")
    Double revenueBetween(@Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    @Query("select coalesce(sum(t.price), 0.0) from Ticket t where t.outTime is not null")
    Double totalRevenue();

    @Query("select coalesce(sum(t.price), 0.0) from Ticket t where t.outTime is not null and t.category = :category")
    Double revenueForCategory(@Param("category") Category category);
}
