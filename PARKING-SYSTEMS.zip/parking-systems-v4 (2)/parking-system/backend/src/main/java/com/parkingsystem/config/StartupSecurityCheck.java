package com.parkingsystem.config;

import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.env.Environment;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/** Warns about demo passwords, and refuses to start with them when the MySQL profile (real data) is on. */
@Component
@Order(0)
public class StartupSecurityCheck implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(StartupSecurityCheck.class);

    private final Environment env;
    private final String adminPassword;
    private final String staffPassword;
    private final String jwtSecret;

    public StartupSecurityCheck(Environment env,
                                @Value("${app.admin.password}") String adminPassword,
                                @Value("${app.staff.password}") String staffPassword,
                                @Value("${app.jwt.secret:}") String jwtSecret) {
        this.env = env;
        this.adminPassword = adminPassword;
        this.staffPassword = staffPassword;
        this.jwtSecret = jwtSecret;
    }

    @Override
    public void run(String... args) {
        boolean demoPasswords = "admin123".equals(adminPassword) || "user123".equals(staffPassword);
        boolean realDatabase = Arrays.asList(env.getActiveProfiles()).contains("mysql");

        if (realDatabase && (demoPasswords || jwtSecret.isBlank())) {
            throw new IllegalStateException(
                    "Set ADMIN_PASSWORD, STAFF_PASSWORD and JWT_SECRET before using the mysql profile.");
        }
        if (demoPasswords) {
            log.warn("Demo passwords (admin123 / user123) are in use. Fine for local testing only. "
                    + "Set ADMIN_PASSWORD and STAFF_PASSWORD environment variables before real use.");
        }
    }
}
