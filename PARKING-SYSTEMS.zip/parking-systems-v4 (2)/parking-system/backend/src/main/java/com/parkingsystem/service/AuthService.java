package com.parkingsystem.service;

import com.parkingsystem.dto.AuthResponse;
import com.parkingsystem.dto.LoginRequest;
import com.parkingsystem.dto.RegisterRequest;
import com.parkingsystem.exception.ConflictException;
import com.parkingsystem.exception.ForbiddenException;
import com.parkingsystem.exception.UnauthorizedException;
import com.parkingsystem.model.AppUser;
import com.parkingsystem.model.Role;
import com.parkingsystem.repository.AppUserRepository;
import com.parkingsystem.security.JwtService;
import com.parkingsystem.security.LoginAttemptService;
import java.util.Locale;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final AppUserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final LoginAttemptService attempts;
    private final boolean allowRegistration;

    public AuthService(AppUserRepository users, PasswordEncoder encoder, JwtService jwt, LoginAttemptService attempts,
                       @Value("${app.allow-registration:true}") boolean allowRegistration) {
        this.users = users;
        this.encoder = encoder;
        this.jwt = jwt;
        this.attempts = attempts;
        this.allowRegistration = allowRegistration;
    }

    public AuthResponse login(LoginRequest request, String clientAddress) {
        String key = clientAddress + "|" + normalize(request.username());
        attempts.checkAllowed(key);
        AppUser user = users.findByUsername(normalize(request.username()))
                .filter(u -> encoder.matches(request.password(), u.getPasswordHash()))
                .orElse(null);
        if (user == null) {
            attempts.recordFailure(key);
            throw new UnauthorizedException("Wrong username or password.");
        }
        attempts.recordSuccess(key);
        return response(user);
    }

    public AuthResponse register(RegisterRequest request) {
        if (!allowRegistration) {
            throw new ForbiddenException("Self-registration is turned off. Ask an admin for an account.");
        }
        String username = normalize(request.username());
        if (users.existsByUsername(username)) {
            throw new ConflictException("That username is already taken.");
        }
        AppUser user = users.save(new AppUser(username, encoder.encode(request.password()),
                request.fullName().trim(), Role.USER));
        return response(user);
    }

    private AuthResponse response(AppUser user) {
        return new AuthResponse(jwt.generate(user), user.getUsername(), user.getFullName(), user.getRole());
    }

    private static String normalize(String username) {
        return username.trim().toLowerCase(Locale.ROOT);
    }
}
