package com.parkingsystem.security;

import com.parkingsystem.exception.TooManyRequestsException;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;

/** Blocks password guessing: 5 wrong passwords for the same account from the same address locks it for 15 minutes. */
@Service
public class LoginAttemptService {

    private static final int MAX_FAILURES = 5;
    private static final Duration LOCK_TIME = Duration.ofMinutes(15);
    private static final int MAX_TRACKED = 10_000;

    private record Attempt(int failures, Instant lockedUntil, Instant lastFailure) {
    }

    private final ConcurrentHashMap<String, Attempt> attempts = new ConcurrentHashMap<>();

    public void checkAllowed(String key) {
        Attempt a = attempts.get(key);
        if (a != null && a.lockedUntil() != null && Instant.now().isBefore(a.lockedUntil())) {
            long minutes = Math.max(1, Duration.between(Instant.now(), a.lockedUntil()).toMinutes() + 1);
            throw new TooManyRequestsException("Too many failed sign-ins. Try again in about " + minutes + " minutes.");
        }
    }

    public void recordFailure(String key) {
        Instant now = Instant.now();
        if (attempts.size() > MAX_TRACKED) {
            attempts.entrySet().removeIf(e -> e.getValue().lastFailure().isBefore(now.minus(LOCK_TIME)));
        }
        attempts.merge(key, new Attempt(1, null, now), (old, fresh) -> {
            boolean expired = old.lockedUntil() != null && now.isAfter(old.lockedUntil());
            int failures = expired ? 1 : old.failures() + 1;
            Instant lock = failures >= MAX_FAILURES ? now.plus(LOCK_TIME) : null;
            return new Attempt(failures, lock, now);
        });
    }

    public void recordSuccess(String key) {
        attempts.remove(key);
    }
}
