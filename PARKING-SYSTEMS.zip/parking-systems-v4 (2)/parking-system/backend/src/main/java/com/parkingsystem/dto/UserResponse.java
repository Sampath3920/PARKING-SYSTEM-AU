package com.parkingsystem.dto;

import com.parkingsystem.model.AppUser;
import com.parkingsystem.model.Role;

public record UserResponse(Long id, String username, String fullName, Role role) {

    public static UserResponse from(AppUser u) {
        return new UserResponse(u.getId(), u.getUsername(), u.getFullName(), u.getRole());
    }
}
