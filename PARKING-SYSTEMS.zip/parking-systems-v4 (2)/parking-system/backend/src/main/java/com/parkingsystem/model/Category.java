package com.parkingsystem.model;

/** Who is parking. Decides which fare rule applies. */
public enum Category {
    STUDENT,
    FACULTY,
    VISITOR
}
