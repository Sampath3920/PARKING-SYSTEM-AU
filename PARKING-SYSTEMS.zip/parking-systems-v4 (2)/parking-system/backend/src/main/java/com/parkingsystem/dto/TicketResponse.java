package com.parkingsystem.dto;

import com.parkingsystem.model.Category;
import com.parkingsystem.model.ParkingType;
import com.parkingsystem.model.PaymentMethod;
import com.parkingsystem.model.PaymentStatus;
import com.parkingsystem.model.Ticket;
import java.time.LocalDateTime;

public record TicketResponse(
        Long id,
        Integer spotNumber,
        ParkingType type,
        Category category,
        String vehicleRegNumber,
        String personName,
        String personRef,
        LocalDateTime inTime,
        LocalDateTime outTime,
        Double price,
        String fareNote,
        String status,
        PaymentStatus paymentStatus,
        PaymentMethod paymentMethod,
        LocalDateTime paidAt,
        String paidBy) {

    public static TicketResponse from(Ticket t) {
        return new TicketResponse(
                t.getId(),
                t.getSpot().getId(),
                t.getSpot().getType(),
                t.getCategory(),
                t.getVehicleRegNumber(),
                t.getPersonName(),
                t.getPersonRef(),
                t.getInTime(),
                t.getOutTime(),
                t.getPrice(),
                t.getFareNote(),
                t.getOutTime() == null ? "PARKED" : "EXITED",
                t.getPaymentStatus(),
                t.getPaymentMethod(),
                t.getPaidAt(),
                t.getPaidBy());
    }
}
