package com.parkingsystem.controller;

import com.parkingsystem.dto.EntryRequest;
import com.parkingsystem.dto.ExitRequest;
import com.parkingsystem.dto.PayRequest;
import com.parkingsystem.dto.RatesDto;
import com.parkingsystem.dto.SpotResponse;
import com.parkingsystem.dto.TicketResponse;
import com.parkingsystem.model.ParkingType;
import com.parkingsystem.service.ParkingService;
import com.parkingsystem.service.RatesService;
import jakarta.validation.Valid;
import java.security.Principal;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

/** Endpoints for every signed-in user (staff and admin). */
@RestController
@RequestMapping("/api")
public class ParkingController {

    private final ParkingService service;
    private final RatesService rates;

    public ParkingController(ParkingService service, RatesService rates) {
        this.service = service;
        this.rates = rates;
    }

    @GetMapping("/parking/availability")
    public Map<ParkingType, Long> availability() {
        return service.availability();
    }

    @GetMapping("/parking/spots")
    public List<SpotResponse> spots() {
        return service.allSpots().stream().map(SpotResponse::from).toList();
    }

    @GetMapping("/rates")
    public RatesDto rates() {
        return RatesDto.from(rates.get());
    }

    @GetMapping("/tickets/parked")
    public List<TicketResponse> parked() {
        return service.parkedNow().stream().map(TicketResponse::from).toList();
    }

    @PostMapping("/tickets/entry")
    @ResponseStatus(HttpStatus.CREATED)
    public TicketResponse enter(@Valid @RequestBody EntryRequest request) {
        return TicketResponse.from(service.enter(request));
    }

    @PostMapping("/tickets/exit")
    public TicketResponse exit(@Valid @RequestBody ExitRequest request) {
        return TicketResponse.from(service.exit(request.vehicleRegNumber()));
    }

    @GetMapping("/tickets/unpaid")
    public List<TicketResponse> unpaid() {
        return service.unpaid().stream().map(TicketResponse::from).toList();
    }

    @PostMapping("/tickets/pay")
    public TicketResponse pay(@Valid @RequestBody PayRequest request, Principal principal) {
        return TicketResponse.from(service.pay(request.vehicleRegNumber(), request.method(), principal.getName()));
    }
}
