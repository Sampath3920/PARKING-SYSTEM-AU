package com.parkingsystem.model;

public enum ParkingType {
    CAR,
    BIKE
}
