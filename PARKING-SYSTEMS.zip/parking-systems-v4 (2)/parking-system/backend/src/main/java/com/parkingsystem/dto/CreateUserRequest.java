package com.parkingsystem.dto;

import com.parkingsystem.model.Role;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateUserRequest(
        @NotBlank @Size(min = 3, max = 30, message = "must be 3 to 30 characters") String username,
        @NotBlank @Size(min = 8, max = 72, message = "must be 8 to 72 characters") String password,
        @NotBlank @Size(max = 100) String fullName,
        @NotNull(message = "is required") Role role) {
}
