package com.parkingsystem.dto;

import com.parkingsystem.model.Role;

public record AuthResponse(String token, String username, String fullName, Role role) {
}
