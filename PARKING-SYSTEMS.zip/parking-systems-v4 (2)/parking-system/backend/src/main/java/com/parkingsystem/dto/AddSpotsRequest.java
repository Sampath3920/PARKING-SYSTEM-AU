package com.parkingsystem.dto;

import com.parkingsystem.model.ParkingType;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record AddSpotsRequest(
        @NotNull(message = "is required") ParkingType type,
        @Min(value = 1, message = "must be at least 1") @Max(value = 50, message = "must be 50 or fewer") int count) {
}
