package com.parkingsystem.model;

public enum Role {
    ADMIN,
    USER
}
