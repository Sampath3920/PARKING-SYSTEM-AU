package com.parkingsystem.dto;

import com.parkingsystem.model.ParkingRates;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.PositiveOrZero;

public record RatesDto(
        @PositiveOrZero(message = "must not be negative") @DecimalMax(value = "100000", message = "is too large") double studentFacultyDayRate,
        @Min(value = 0, message = "must not be negative") @Max(value = 1440, message = "must be 1440 or fewer") int visitorFreeMinutes,
        @PositiveOrZero(message = "must not be negative") @DecimalMax(value = "100000", message = "is too large") double visitorHourlyRate) {

    public static RatesDto from(ParkingRates r) {
        return new RatesDto(r.getStudentFacultyDayRate(), r.getVisitorFreeMinutes(), r.getVisitorHourlyRate());
    }
}
