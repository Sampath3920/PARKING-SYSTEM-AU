package com.parkingsystem.controller;

import com.parkingsystem.dto.AddSpotsRequest;
import com.parkingsystem.dto.CreateUserRequest;
import com.parkingsystem.dto.RatesDto;
import com.parkingsystem.dto.SpotResponse;
import com.parkingsystem.dto.StatsResponse;
import com.parkingsystem.dto.TicketResponse;
import com.parkingsystem.dto.UserResponse;
import com.parkingsystem.service.ParkingService;
import com.parkingsystem.service.RatesService;
import com.parkingsystem.service.StatsService;
import com.parkingsystem.service.UserService;
import jakarta.validation.Valid;
import java.security.Principal;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

/** Admin-only endpoints (enforced in SecurityConfig for /api/admin/**). */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final StatsService stats;
    private final ParkingService parking;
    private final RatesService rates;
    private final UserService users;

    public AdminController(StatsService stats, ParkingService parking, RatesService rates, UserService users) {
        this.stats = stats;
        this.parking = parking;
        this.rates = rates;
        this.users = users;
    }

    @GetMapping("/stats")
    public StatsResponse stats() {
        return stats.stats();
    }

    @GetMapping("/tickets")
    public List<TicketResponse> history(@RequestParam(required = false) String q) {
        return parking.history(q).stream().map(TicketResponse::from).toList();
    }

    @PutMapping("/rates")
    public RatesDto updateRates(@Valid @RequestBody RatesDto dto) {
        return RatesDto.from(rates.update(dto));
    }

    @PostMapping("/spots")
    @ResponseStatus(HttpStatus.CREATED)
    public List<SpotResponse> addSpots(@Valid @RequestBody AddSpotsRequest request) {
        return parking.addSpots(request.type(), request.count()).stream().map(SpotResponse::from).toList();
    }

    @GetMapping("/payments")
    public List<TicketResponse> payments() {
        return parking.payments().stream().map(TicketResponse::from).toList();
    }

    @DeleteMapping("/spots/{number}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removeSpot(@PathVariable int number) {
        parking.removeSpot(number);
    }

    @GetMapping("/users")
    public List<UserResponse> users() {
        return users.list().stream().map(UserResponse::from).toList();
    }

    @PostMapping("/users")
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse createUser(@Valid @RequestBody CreateUserRequest request) {
        return UserResponse.from(users.create(request));
    }

    @DeleteMapping("/users/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteUser(@PathVariable Long id, Principal principal) {
        users.delete(id, principal.getName());
    }
}
