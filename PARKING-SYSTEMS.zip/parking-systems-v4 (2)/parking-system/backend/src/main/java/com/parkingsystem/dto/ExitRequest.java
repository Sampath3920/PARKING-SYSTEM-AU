package com.parkingsystem.dto;

import jakarta.validation.constraints.NotBlank;

public record ExitRequest(@NotBlank(message = "is required") String vehicleRegNumber) {
}
