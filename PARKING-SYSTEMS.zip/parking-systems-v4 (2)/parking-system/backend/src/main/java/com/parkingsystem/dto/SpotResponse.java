package com.parkingsystem.dto;

import com.parkingsystem.model.ParkingSpot;
import com.parkingsystem.model.ParkingType;

public record SpotResponse(Integer number, ParkingType type, boolean available) {

    public static SpotResponse from(ParkingSpot s) {
        return new SpotResponse(s.getId(), s.getType(), s.isAvailable());
    }
}
