package com.parkingsystem.dto;

import com.parkingsystem.model.PaymentMethod;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record PayRequest(
        @NotBlank(message = "is required") String vehicleRegNumber,
        @NotNull(message = "is required") PaymentMethod method) {
}
