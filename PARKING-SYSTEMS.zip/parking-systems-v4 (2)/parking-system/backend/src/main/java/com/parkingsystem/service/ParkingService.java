package com.parkingsystem.service;

import com.parkingsystem.dto.EntryRequest;
import com.parkingsystem.exception.ConflictException;
import com.parkingsystem.exception.NotFoundException;
import com.parkingsystem.model.ParkingSpot;
import com.parkingsystem.model.ParkingType;
import com.parkingsystem.model.PaymentMethod;
import com.parkingsystem.model.PaymentStatus;
import com.parkingsystem.model.Ticket;
import com.parkingsystem.repository.ParkingSpotRepository;
import com.parkingsystem.repository.TicketRepository;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ParkingService {

    private final ParkingSpotRepository spots;
    private final TicketRepository tickets;
    private final FareCalculatorService fares;
    private final RatesService rates;

    public ParkingService(ParkingSpotRepository spots, TicketRepository tickets,
                          FareCalculatorService fares, RatesService rates) {
        this.spots = spots;
        this.tickets = tickets;
        this.fares = fares;
        this.rates = rates;
    }

    @Transactional
    public Ticket enter(EntryRequest request) {
        String reg = normalize(request.vehicleRegNumber());

        if (tickets.findByVehicleRegNumberAndOutTimeIsNull(reg).isPresent()) {
            throw new ConflictException("Vehicle " + reg + " is already parked.");
        }

        ParkingType type = request.type();
        ParkingSpot spot = spots.findFirstByTypeAndAvailableTrueAndEnabledTrueOrderByIdAsc(type)
                .orElseThrow(() -> new ConflictException("No free " + type.name().toLowerCase() + " bays."));
        spot.setAvailable(false);

        Ticket ticket = new Ticket();
        ticket.setSpot(spot);
        ticket.setVehicleRegNumber(reg);
        ticket.setCategory(request.category());
        ticket.setPersonName(request.personName().trim());
        ticket.setPersonRef(blankToNull(request.personRef()));
        ticket.setInTime(LocalDateTime.now());
        return tickets.save(ticket);
    }

    @Transactional
    public Ticket exit(String regNumber) {
        String reg = normalize(regNumber);

        Ticket ticket = tickets.findByVehicleRegNumberAndOutTimeIsNull(reg)
                .orElseThrow(() -> new NotFoundException("Vehicle " + reg + " is not parked."));

        LocalDateTime out = LocalDateTime.now();
        FareCalculatorService.Fare fare = fares.calculate(ticket.getCategory(), ticket.getInTime(), out, rates.get());

        ticket.setOutTime(out);
        ticket.setPrice(fare.amount());
        ticket.setFareNote(fare.note());
        ticket.setPaymentStatus(fare.amount() > 0 ? PaymentStatus.PENDING : PaymentStatus.NOT_REQUIRED);
        ticket.getSpot().setAvailable(true);
        return ticket;
    }

    /** The user marks an exited vehicle's fare as paid; the admin sees it in the payments list. */
    @Transactional
    public Ticket pay(String regNumber, PaymentMethod method, String paidBy) {
        String reg = normalize(regNumber);
        Ticket ticket = tickets
                .findFirstByVehicleRegNumberAndPaymentStatusOrderByOutTimeDesc(reg, PaymentStatus.PENDING)
                .orElseThrow(() -> new NotFoundException("No pending payment for vehicle " + reg + "."));
        ticket.setPaymentStatus(PaymentStatus.PAID);
        ticket.setPaymentMethod(method);
        ticket.setPaidBy(paidBy);
        ticket.setPaidAt(LocalDateTime.now());
        return ticket;
    }

    @Transactional(readOnly = true)
    public List<Ticket> unpaid() {
        return tickets.findByPaymentStatusOrderByOutTimeDesc(PaymentStatus.PENDING);
    }

    @Transactional(readOnly = true)
    public List<Ticket> payments() {
        return tickets.findByPaymentStatusOrderByPaidAtDesc(PaymentStatus.PAID);
    }

    @Transactional(readOnly = true)
    public Map<ParkingType, Long> availability() {
        Map<ParkingType, Long> result = new EnumMap<>(ParkingType.class);
        for (ParkingType type : ParkingType.values()) {
            result.put(type, spots.countByTypeAndAvailableTrueAndEnabledTrue(type));
        }
        return result;
    }

    @Transactional(readOnly = true)
    public List<ParkingSpot> allSpots() {
        return spots.findAllByEnabledTrueOrderByIdAsc();
    }

    @Transactional
    public List<ParkingSpot> addSpots(ParkingType type, int count) {
        int next = spots.findMaxId() + 1;
        List<ParkingSpot> created = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            created.add(spots.save(new ParkingSpot(next + i, type)));
        }
        return created;
    }

    @Transactional
    public void removeSpot(int number) {
        ParkingSpot spot = spots.findById(number)
                .filter(ParkingSpot::isEnabled)
                .orElseThrow(() -> new NotFoundException("Bay " + number + " does not exist."));
        if (!spot.isAvailable()) {
            throw new ConflictException("Bay " + number + " has a vehicle in it. Release it first.");
        }
        spot.setEnabled(false);
    }

    @Transactional(readOnly = true)
    public List<Ticket> parkedNow() {
        return tickets.findByOutTimeIsNullOrderByInTimeDesc();
    }

    @Transactional(readOnly = true)
    public List<Ticket> history(String query) {
        List<Ticket> all = tickets.findAllByOrderByInTimeDesc();
        if (query == null || query.isBlank()) {
            return all;
        }
        String q = query.trim().toLowerCase(Locale.ROOT);
        return all.stream()
                .filter(t -> contains(t.getVehicleRegNumber(), q)
                        || contains(t.getPersonName(), q)
                        || contains(t.getPersonRef(), q))
                .toList();
    }

    private static boolean contains(String value, String q) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(q);
    }

    private static String normalize(String reg) {
        return reg.trim().toUpperCase(Locale.ROOT);
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
