package com.parkingsystem.dto;

import com.parkingsystem.model.Category;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public record StatsResponse(
        long totalSpots,
        long freeSpots,
        long carTotal,
        long carFree,
        long bikeTotal,
        long bikeFree,
        long parkedNow,
        long entriesToday,
        double revenueToday,
        double revenueThisMonth,
        double revenueTotal,
        Map<Category, Double> revenueByCategory,
        List<DayRevenue> lastSevenDays) {

    public record DayRevenue(LocalDate date, double amount) {
    }
}
