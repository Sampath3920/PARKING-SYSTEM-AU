package com.parkingsystem.service;

import com.parkingsystem.model.Category;
import com.parkingsystem.model.ParkingRates;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import org.springframework.stereotype.Service;

/**
 * Fare rules (the amounts come from the admin-editable rates):
 * - Student and faculty: a flat amount per calendar day parked (default Rs. 1 per day).
 *   Parking on two different dates counts as two days.
 * - Visitor: free up to the free period (default 30 minutes). Beyond that, the whole stay is
 *   charged per hour, rounded up to the next full hour (default Rs. 5 per hour).
 */
@Service
public class FareCalculatorService {

    public record Fare(double amount, String note) {
    }

    public Fare calculate(Category category, LocalDateTime in, LocalDateTime out, ParkingRates rates) {
        if (category == null || in == null || out == null || rates == null) {
            throw new IllegalArgumentException("Category, in time, out time and rates are required");
        }
        if (out.isBefore(in)) {
            throw new IllegalArgumentException("Out time must not be before in time");
        }
        return category == Category.VISITOR ? visitorFare(in, out, rates) : dailyFare(in, out, rates);
    }

    private Fare dailyFare(LocalDateTime in, LocalDateTime out, ParkingRates rates) {
        long days = ChronoUnit.DAYS.between(in.toLocalDate(), out.toLocalDate()) + 1;
        BigDecimal rate = BigDecimal.valueOf(rates.getStudentFacultyDayRate());
        BigDecimal amount = rate.multiply(BigDecimal.valueOf(days));
        String note = days + (days == 1 ? " day" : " days") + " at Rs. " + plain(rate) + " per day";
        return new Fare(round(amount), note);
    }

    private Fare visitorFare(LocalDateTime in, LocalDateTime out, ParkingRates rates) {
        Duration stay = Duration.between(in, out);
        int freeMinutes = rates.getVisitorFreeMinutes();
        if (stay.compareTo(Duration.ofMinutes(freeMinutes)) <= 0) {
            return new Fare(0.0, "Free: stayed " + stay.toMinutes() + " min (first " + freeMinutes + " min free)");
        }
        long hours = (stay.getSeconds() + 3599) / 3600;
        BigDecimal rate = BigDecimal.valueOf(rates.getVisitorHourlyRate());
        BigDecimal amount = rate.multiply(BigDecimal.valueOf(hours));
        String note = hours + (hours == 1 ? " hour" : " hours") + " at Rs. " + plain(rate) + " per hour";
        return new Fare(round(amount), note);
    }

    private static double round(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    private static String plain(BigDecimal value) {
        return value.stripTrailingZeros().toPlainString();
    }
}
