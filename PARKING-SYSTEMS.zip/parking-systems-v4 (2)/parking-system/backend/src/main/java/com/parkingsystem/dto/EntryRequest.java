package com.parkingsystem.dto;

import com.parkingsystem.model.Category;
import com.parkingsystem.model.ParkingType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record EntryRequest(
        @NotBlank(message = "is required") @Size(max = 20, message = "must be 20 characters or fewer") String vehicleRegNumber,
        @NotNull(message = "is required") ParkingType type,
        @NotNull(message = "is required") Category category,
        @NotBlank(message = "is required") @Size(max = 100, message = "must be 100 characters or fewer") String personName,
        @Size(max = 50, message = "must be 50 characters or fewer") String personRef) {
}
