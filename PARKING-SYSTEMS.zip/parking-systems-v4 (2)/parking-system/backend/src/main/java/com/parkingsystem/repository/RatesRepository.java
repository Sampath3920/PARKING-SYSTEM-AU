package com.parkingsystem.repository;

import com.parkingsystem.model.ParkingRates;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RatesRepository extends JpaRepository<ParkingRates, Long> {
}
