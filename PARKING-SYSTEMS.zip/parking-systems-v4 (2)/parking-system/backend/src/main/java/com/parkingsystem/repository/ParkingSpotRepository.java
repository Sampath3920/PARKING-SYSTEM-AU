package com.parkingsystem.repository;

import com.parkingsystem.model.ParkingSpot;
import com.parkingsystem.model.ParkingType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ParkingSpotRepository extends JpaRepository<ParkingSpot, Integer> {

    Optional<ParkingSpot> findFirstByTypeAndAvailableTrueAndEnabledTrueOrderByIdAsc(ParkingType type);

    long countByTypeAndAvailableTrueAndEnabledTrue(ParkingType type);

    List<ParkingSpot> findAllByEnabledTrueOrderByIdAsc();

    @Query("select coalesce(max(s.id), 0) from ParkingSpot s")
    Integer findMaxId();
}
