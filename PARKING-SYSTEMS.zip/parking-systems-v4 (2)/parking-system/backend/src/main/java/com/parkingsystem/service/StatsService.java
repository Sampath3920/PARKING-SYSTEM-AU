package com.parkingsystem.service;

import com.parkingsystem.dto.StatsResponse;
import com.parkingsystem.dto.StatsResponse.DayRevenue;
import com.parkingsystem.model.Category;
import com.parkingsystem.model.ParkingSpot;
import com.parkingsystem.model.ParkingType;
import com.parkingsystem.repository.ParkingSpotRepository;
import com.parkingsystem.repository.TicketRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StatsService {

    private final ParkingSpotRepository spots;
    private final TicketRepository tickets;

    public StatsService(ParkingSpotRepository spots, TicketRepository tickets) {
        this.spots = spots;
        this.tickets = tickets;
    }

    @Transactional(readOnly = true)
    public StatsResponse stats() {
        LocalDate today = LocalDate.now();
        LocalDateTime startOfToday = today.atStartOfDay();
        LocalDateTime startOfTomorrow = today.plusDays(1).atStartOfDay();
        LocalDateTime startOfMonth = today.withDayOfMonth(1).atStartOfDay();
        LocalDateTime startOfNextMonth = today.withDayOfMonth(1).plusMonths(1).atStartOfDay();

        List<ParkingSpot> all = spots.findAllByEnabledTrueOrderByIdAsc();
        long carTotal = all.stream().filter(s -> s.getType() == ParkingType.CAR).count();
        long carFree = all.stream().filter(s -> s.getType() == ParkingType.CAR && s.isAvailable()).count();
        long bikeTotal = all.stream().filter(s -> s.getType() == ParkingType.BIKE).count();
        long bikeFree = all.stream().filter(s -> s.getType() == ParkingType.BIKE && s.isAvailable()).count();

        Map<Category, Double> byCategory = new EnumMap<>(Category.class);
        for (Category category : Category.values()) {
            byCategory.put(category, tickets.revenueForCategory(category));
        }

        List<DayRevenue> week = new ArrayList<>();
        for (int i = 6; i >= 0; i--) {
            LocalDate day = today.minusDays(i);
            week.add(new DayRevenue(day, tickets.revenueBetween(day.atStartOfDay(), day.plusDays(1).atStartOfDay())));
        }

        return new StatsResponse(
                all.size(),
                carFree + bikeFree,
                carTotal,
                carFree,
                bikeTotal,
                bikeFree,
                tickets.countByOutTimeIsNull(),
                tickets.countByInTimeGreaterThanEqual(startOfToday),
                tickets.revenueBetween(startOfToday, startOfTomorrow),
                tickets.revenueBetween(startOfMonth, startOfNextMonth),
                tickets.totalRevenue(),
                byCategory,
                week);
    }
}
