package com.parkingsystem.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ticket")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "parking_number")
    private ParkingSpot spot;

    @Column(name = "vehicle_reg_number", nullable = false, length = 20)
    private String vehicleRegNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Category category;

    @Column(name = "person_name", nullable = false, length = 100)
    private String personName;

    /** Roll number, employee ID or phone number. Optional. */
    @Column(name = "person_ref", length = 50)
    private String personRef;

    private Double price;

    @Column(name = "fare_note", length = 120)
    private String fareNote;

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_status", length = 15)
    private PaymentStatus paymentStatus;

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_method", length = 15)
    private PaymentMethod paymentMethod;

    @Column(name = "paid_by", length = 30)
    private String paidBy;

    @Column(name = "paid_at")
    private LocalDateTime paidAt;

    @Column(name = "in_time", nullable = false)
    private LocalDateTime inTime;

    @Column(name = "out_time")
    private LocalDateTime outTime;

    public Long getId() { return id; }
    public ParkingSpot getSpot() { return spot; }
    public void setSpot(ParkingSpot spot) { this.spot = spot; }
    public String getVehicleRegNumber() { return vehicleRegNumber; }
    public void setVehicleRegNumber(String v) { this.vehicleRegNumber = v; }
    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
    public String getPersonName() { return personName; }
    public void setPersonName(String personName) { this.personName = personName; }
    public String getPersonRef() { return personRef; }
    public void setPersonRef(String personRef) { this.personRef = personRef; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
    public String getFareNote() { return fareNote; }
    public void setFareNote(String fareNote) { this.fareNote = fareNote; }
    public LocalDateTime getInTime() { return inTime; }
    public void setInTime(LocalDateTime inTime) { this.inTime = inTime; }
    public LocalDateTime getOutTime() { return outTime; }
    public void setOutTime(LocalDateTime outTime) { this.outTime = outTime; }
    public PaymentStatus getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(PaymentStatus paymentStatus) { this.paymentStatus = paymentStatus; }
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }
    public LocalDateTime getPaidAt() { return paidAt; }
    public void setPaidAt(LocalDateTime paidAt) { this.paidAt = paidAt; }
    public String getPaidBy() { return paidBy; }
    public void setPaidBy(String paidBy) { this.paidBy = paidBy; }
}
