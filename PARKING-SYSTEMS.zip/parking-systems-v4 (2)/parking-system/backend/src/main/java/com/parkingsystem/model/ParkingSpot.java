package com.parkingsystem.model;

import jakarta.persistence.*;

@Entity
@Table(name = "parking")
public class ParkingSpot {

    @Id
    @Column(name = "parking_number")
    private Integer id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private ParkingType type;

    @Column(nullable = false)
    private boolean available = true;

    /** Removed bays are disabled, not deleted, so old tickets keep pointing at them. */
    @Column(nullable = false)
    private boolean enabled = true;

    protected ParkingSpot() {
    }

    public ParkingSpot(Integer id, ParkingType type) {
        this.id = id;
        this.type = type;
    }

    public Integer getId() { return id; }
    public ParkingType getType() { return type; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}
