package com.parkingsystem.service;

import com.parkingsystem.dto.RatesDto;
import com.parkingsystem.model.ParkingRates;
import com.parkingsystem.repository.RatesRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RatesService {

    private static final long ROW_ID = 1L;

    private final RatesRepository repository;

    public RatesService(RatesRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public ParkingRates get() {
        return repository.findById(ROW_ID)
                .orElseGet(() -> repository.save(new ParkingRates(ROW_ID, 1.0, 30, 5.0)));
    }

    @Transactional
    public ParkingRates update(RatesDto dto) {
        ParkingRates rates = get();
        rates.setStudentFacultyDayRate(dto.studentFacultyDayRate());
        rates.setVisitorFreeMinutes(dto.visitorFreeMinutes());
        rates.setVisitorHourlyRate(dto.visitorHourlyRate());
        return rates;
    }
}
