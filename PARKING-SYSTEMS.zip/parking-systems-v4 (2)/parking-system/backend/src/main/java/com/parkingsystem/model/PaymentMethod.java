package com.parkingsystem.model;

public enum PaymentMethod {
    CASH,
    UPI,
    CREDIT_CARD,
    DEBIT_CARD,
    NET_BANKING,
    WALLET
}
