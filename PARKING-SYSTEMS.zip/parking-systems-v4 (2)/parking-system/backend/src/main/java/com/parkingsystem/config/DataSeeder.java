package com.parkingsystem.config;

import com.parkingsystem.model.AppUser;
import com.parkingsystem.model.ParkingSpot;
import com.parkingsystem.model.ParkingType;
import com.parkingsystem.model.Role;
import com.parkingsystem.repository.AppUserRepository;
import com.parkingsystem.repository.ParkingSpotRepository;
import com.parkingsystem.service.RatesService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** On first start: creates the bays, the default fares and the two starter accounts. */
@Component
public class DataSeeder implements CommandLineRunner {

    private final ParkingSpotRepository spots;
    private final AppUserRepository users;
    private final RatesService rates;
    private final PasswordEncoder encoder;
    private final int carSpots;
    private final int bikeSpots;
    private final String adminUsername;
    private final String adminPassword;
    private final String staffUsername;
    private final String staffPassword;

    public DataSeeder(ParkingSpotRepository spots, AppUserRepository users, RatesService rates,
                      PasswordEncoder encoder,
                      @Value("${parking.car-spots:3}") int carSpots,
                      @Value("${parking.bike-spots:2}") int bikeSpots,
                      @Value("${app.admin.username}") String adminUsername,
                      @Value("${app.admin.password}") String adminPassword,
                      @Value("${app.staff.username}") String staffUsername,
                      @Value("${app.staff.password}") String staffPassword) {
        this.spots = spots;
        this.users = users;
        this.rates = rates;
        this.encoder = encoder;
        this.carSpots = carSpots;
        this.bikeSpots = bikeSpots;
        this.adminUsername = adminUsername;
        this.adminPassword = adminPassword;
        this.staffUsername = staffUsername;
        this.staffPassword = staffPassword;
    }

    @Override
    public void run(String... args) {
        rates.get();

        if (spots.count() == 0) {
            int number = 1;
            for (int i = 0; i < carSpots; i++) {
                spots.save(new ParkingSpot(number++, ParkingType.CAR));
            }
            for (int i = 0; i < bikeSpots; i++) {
                spots.save(new ParkingSpot(number++, ParkingType.BIKE));
            }
        }

        if (users.count() == 0) {
            users.save(new AppUser(adminUsername, encoder.encode(adminPassword), "Administrator", Role.ADMIN));
            users.save(new AppUser(staffUsername, encoder.encode(staffPassword), "Parking Staff", Role.USER));
        }
    }
}
