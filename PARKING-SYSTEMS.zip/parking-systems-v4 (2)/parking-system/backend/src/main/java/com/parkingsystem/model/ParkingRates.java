package com.parkingsystem.model;

import jakarta.persistence.*;

/** One row (id = 1) holding the fares. Admins can change these from the dashboard. */
@Entity
@Table(name = "rates")
public class ParkingRates {

    @Id
    private Long id;

    @Column(name = "student_faculty_day_rate", nullable = false)
    private double studentFacultyDayRate;

    @Column(name = "visitor_free_minutes", nullable = false)
    private int visitorFreeMinutes;

    @Column(name = "visitor_hourly_rate", nullable = false)
    private double visitorHourlyRate;

    protected ParkingRates() {
    }

    public ParkingRates(Long id, double studentFacultyDayRate, int visitorFreeMinutes, double visitorHourlyRate) {
        this.id = id;
        this.studentFacultyDayRate = studentFacultyDayRate;
        this.visitorFreeMinutes = visitorFreeMinutes;
        this.visitorHourlyRate = visitorHourlyRate;
    }

    public Long getId() { return id; }
    public double getStudentFacultyDayRate() { return studentFacultyDayRate; }
    public void setStudentFacultyDayRate(double v) { this.studentFacultyDayRate = v; }
    public int getVisitorFreeMinutes() { return visitorFreeMinutes; }
    public void setVisitorFreeMinutes(int v) { this.visitorFreeMinutes = v; }
    public double getVisitorHourlyRate() { return visitorHourlyRate; }
    public void setVisitorHourlyRate(double v) { this.visitorHourlyRate = v; }
}
