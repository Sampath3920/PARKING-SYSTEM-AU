package com.parkingsystem.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.parkingsystem.model.Category;
import com.parkingsystem.model.ParkingRates;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;

class FareCalculatorServiceTest {

    private final FareCalculatorService service = new FareCalculatorService();
    private final ParkingRates rates = new ParkingRates(1L, 1.0, 30, 5.0);
    private final LocalDateTime in = LocalDateTime.of(2026, 1, 1, 10, 0);

    private double fare(Category category, LocalDateTime out) {
        return service.calculate(category, in, out, rates).amount();
    }

    @Test
    void studentSameDayPaysOneDay() {
        assertEquals(1.0, fare(Category.STUDENT, in.plusHours(6)));
    }

    @Test
    void facultyOvernightPaysTwoDays() {
        assertEquals(2.0, service.calculate(Category.FACULTY,
                LocalDateTime.of(2026, 1, 1, 22, 0), LocalDateTime.of(2026, 1, 2, 8, 0), rates).amount());
    }

    @Test
    void studentThreeCalendarDays() {
        assertEquals(3.0, fare(Category.STUDENT, in.plusDays(2)));
    }

    @Test
    void visitorFirstThirtyMinutesFree() {
        assertEquals(0.0, fare(Category.VISITOR, in.plusMinutes(30)));
    }

    @Test
    void visitorJustOverThirtyMinutesPaysOneHour() {
        assertEquals(5.0, fare(Category.VISITOR, in.plusMinutes(31)));
    }

    @Test
    void visitorOneHourOneMinutePaysTwoHours() {
        assertEquals(10.0, fare(Category.VISITOR, in.plusMinutes(61)));
    }

    @Test
    void visitorExactlyTwoHours() {
        assertEquals(10.0, fare(Category.VISITOR, in.plusHours(2)));
    }

    @Test
    void adminChangedRatesAreUsed() {
        ParkingRates custom = new ParkingRates(1L, 2.0, 15, 10.0);
        assertEquals(4.0, service.calculate(Category.STUDENT, in, in.plusDays(1), custom).amount());
        assertEquals(10.0, service.calculate(Category.VISITOR, in, in.plusMinutes(20), custom).amount());
    }

    @Test
    void outBeforeInIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> fare(Category.VISITOR, in.minusHours(1)));
    }
}
